//
//  ViewController.swift
//  JSONDemo2
//
//  Created by Asif Ikbal on 4/24/17.
//  Copyright © 2017 Asif Ikbal. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {
    
    var addressArray = [[String: String]]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let pathToFile = Bundle.main.url(forResource: "customer", withExtension: "json")
        
        do {
            let data = try Data(contentsOf: pathToFile!)
            
            let jsonRoot = try JSONSerialization.jsonObject(with: data, options: [])
            print(jsonRoot)
            
//            let valueForAddress = jsonRoot?["address"] as? [String: Any]
//            print(valueForAddress!)
            
            
        }
        catch {
            print(error)
        }
    }




}

