

//
//  CD.swift
//  AnotherXML
//
//  Created by Asif Ikbal on 4/23/17.
//  Copyright © 2017 Asif Ikbal. All rights reserved.
//

import Foundation

class CD {
    
    var title: String = ""
    var artist: String = ""
    var country:String = ""
    var company: String = ""
    var price: Double = 0.0
    var year: Int = 0
    
    init() {
        
    }
}
