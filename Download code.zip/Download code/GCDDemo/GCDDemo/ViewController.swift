//
//  ViewController.swift
//  GCDDemo
//
//  Created by Sayem on 5/7/17.
//  Copyright © 2017 Sayem. All rights reserved.
//

import UIKit
//import <#module#>

class ViewController: UIViewController {
    
    // Main queue... have main thread
    var mainQueue = DispatchQueue.main
    
    // default global queue
    // queue with default priority
    var myQueue:DispatchQueue = DispatchQueue.global()
    
    // one more queue with priority as userInitiated
    var globalQueue:DispatchQueue = DispatchQueue.global(qos: .userInitiated)
    
    // private queue
    // default is serial queue
    var privateQueue = DispatchQueue(label: "StartUp")
    
    // private/custom concurrent queue
    // we can also have concurrent queue
    
    var conQueue = DispatchQueue(label: "Startup 2", attributes: .concurrent, autoreleaseFrequency: .never, target: nil)
    
    @IBOutlet weak var labelOutlet: UILabel!
    
    @IBAction func buttonRun(_ sender: Any) {
        
        myQueue.async {
            self.runningTask1(a: 5)
        }
        myQueue.async {
            self.runningTask2(a: 4)
        }
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    func runningTask1(a: Double) {
        print("Task 1 started")
        //Simulting the task for a second
        Thread.sleep(forTimeInterval: a)
        print("Task 1 Ends...")
        
        DispatchQueue.main.async {
           self.labelOutlet.text = String(a)

        }
    }
    
    func runningTask2(a: Double) {
        print("Task 2 started")
        //Simulting the task for a second
        Thread.sleep(forTimeInterval: a)
        print("Task 2 Ends...")
        DispatchQueue.main.async {
            self.labelOutlet.text = String(a)

        }
    }

}

