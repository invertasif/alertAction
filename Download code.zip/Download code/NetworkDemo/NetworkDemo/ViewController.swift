//
//  ViewController.swift
//  NetworkDemo
//
//  Created by Asif Ikbal on 5/8/17.
//  Copyright © 2017 Asif Ikbal. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let urlString = "https://api.darksky.net/forecast/c197ee76215f3eb0883ba6b2a018b0c9/37.8267,-122.4233"
    

    @IBOutlet weak var imageView: UIImageView!
    

    @IBAction func downloadAction(_ sender: Any) {
        
        
        let url = URL(string: urlString)
        let downloadTask = URLSession.shared.dataTask(with: url!) { (data, response, error) in
//            print(data)
//            print(response)
//            print(error)

            if let error = error {
                print(error)
            }
            
            if let data = data {
                DispatchQueue.main.async {
                    self.imageView.image = UIImage(data: data)
                }
            }

        }
        
        // data task is by default in suspended state
        // start task by calling resume 
        downloadTask.resume()
        
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

