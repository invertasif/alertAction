//
//  ViewController.swift
//  WeatherApp
//
//  Created by Asif Ikbal on 5/9/17.
//  Copyright © 2017 Asif Ikbal. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let jsonFilePath = URL(string: "https://api.darksky.net/forecast/c197ee76215f3eb0883ba6b2a018b0c9/37.8267,-122.4233")
        var jsonData:Data = Data()
        do {
            jsonData = try Data(contentsOf: jsonFilePath!, options: [])
        } catch{
            print(error)
        }
        do {
            let jsonRoot = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any]
            let latitudeData = jsonRoot?["latitude"] as? Double
            //print(latitudeData!)
            //print(jsonRoot!)
            let longitudeData = jsonRoot?["longitude"] as? Double
            //print(longitudeData!)
            let currently = jsonRoot?["currently"] as? [String: Any]
            print(currently!)
            
            let summary = currently?["summary"] as? String
            print(summary!)
            let icon = currently?["icon"] as? String
            print(icon!)
            
        }catch{
            print(error)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


