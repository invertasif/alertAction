//
//  Configuration.swift
//  WeatherApp
//
//  Created by Asif Ikbal on 5/9/17.
//  Copyright © 2017 Asif Ikbal. All rights reserved.
//

import Foundation


struct API {
    
    let APIKey = "c197ee76215f3eb0883ba6b2a018b0c9"
    let APIURL = URL(fileURLWithPath: "https://api.darksky.net/forecast/c197ee76215f3eb0883ba6b2a018b0c9")
    
    var authenticatedURL: URL {
        return APIURL.appendingPathComponent(APIKey)
    }
    
    
}

struct Defaults {
    
    let latitude = 37.8267
    let longitude = -122.423
    
    
}

