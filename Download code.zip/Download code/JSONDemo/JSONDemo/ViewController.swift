//
//  ViewController.swift
//  JSONDemo
//
//  Created by Asif Ikbal on 4/24/17.
//  Copyright © 2017 Asif Ikbal. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {
    
 //   var foodArray  = [Food]()
    
    var customerArray = [Customer]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
  //      foodArray = Food.setData()
    }

    
//    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
////        return foodArray.count
//    }
//    
//    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//   
//        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
//        
//   //     let foodObj = foodArray[indexPath.row]
//        
//        cell?.textLabel?.text = foodObj.name
//        cell?.detailTextLabel?.text = foodObj.description
//        
//        return cell!
//    }

}

