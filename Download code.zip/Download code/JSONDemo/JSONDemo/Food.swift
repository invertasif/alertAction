

//
//  Food.swift
//  JSONDemo
//
//  Created by Asif Ikbal on 4/25/17.
//  Copyright © 2017 Asif Ikbal. All rights reserved.
//

import Foundation
import UIKit

//struct Food {
//    
//    static var foodArray:[Food] = []
//
//    var name: String = ""
//    var description: String = ""
//    var calories: String = ""
//    var price: String = ""
//    
//}
struct Customer {
    
    static var customerArray:[Customer] = []
    var firstName: String = ""
    var lastName: String = ""
    var age: Int = 0
}


struct Address {
    var streetAddress: String = ""
    var city:String = ""
    var state: String = ""
    var postalCode: String = ""
    
}

struct CustomerPhoneNumber {
    var type: String = ""
    var mumber: String = ""
}

enum SerialiazationError :Error {
    case missing(String)
}

//extension Food {
//    init(food: [String:String]) throws {
//        guard let name = food["name"] else {
//            throw SerialiazationError.missing("name")
//        }
//        guard let description = food["description"] else {
//            throw SerialiazationError.missing("description")
//        }
//        guard let calories = food["calories"] else {
//            throw SerialiazationError.missing("calories")
//        }
//        
//        guard let price = food["price"] else {
//            throw SerialiazationError.missing("price")
//        }
//        
//        self.name = name
//        self.description = description
//        self.price = price
//        self.calories = calories
//    }
//    
//}

extension Address {
    init(address: [String:Any]) throws  {
        guard let streetAddress = address["streetAddress"] else {
            throw SerialiazationError.missing("streetAddress")
        }
        guard let city = address["city"] else {
            throw SerialiazationError.missing("city")
        }
        guard let state = address["state"] else {
            throw SerialiazationError.missing("state")
        }
        guard let postalCode = address["postalCode"] else {
            throw SerialiazationError.missing("postalCode")
        }
        
        self.streetAddress = streetAddress as! String
        self.state = state as! String
        self.city = city as! String
        self.postalCode = postalCode as! String
    }
}


extension Customer {
    
    static func setData() -> [Customer] {
        
        
       // let pathToFile = Bundle.main.url(forResource: "simple", withExtension: "json")
        
        let pathToFile = Bundle.main.url(forResource: "customer", withExtension: "json")
        print(pathToFile!)
        do {
            
//            let data =  try Data(contentsOf: pathToFile!)
//            let jsonRoot = try JSONSerialization.jsonObject(with: data, options: [] ) as? [String: Any]
//            
//            let valueForMenu = jsonRoot?["menu"] as? [String: Any]
//            
//            let array = valueForMenu?["food"] as! [[String: String]]
//            
//            for item in array {
//                do {
//                    foodArray.append(try Food(food: item))
//                }
//                catch {
//                    print(error)
//                }
//            }
            
            let data = try Data(contentsOf: pathToFile!)
            
            let jsonRoot = try JSONSerialization.jsonObject(with: data, options: [] ) as? [Any]
            print(jsonRoot!)
//            let valueForCustomer = jsonRoot?[""] as? [String:Any]
//            let array = valueForCustomer?[""] as! [[String: Any]]
//            print(array)

        }
        catch {
            print(error)
        }

        return customerArray
    }
}
