//
//  ViewController.swift
//  JsonDemo3
//
//  Created by Asif Ikbal on 4/25/17.
//  Copyright © 2017 Asif Ikbal. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.


    }



}

